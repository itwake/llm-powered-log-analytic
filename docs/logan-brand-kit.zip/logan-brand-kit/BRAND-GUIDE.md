# LogAn brand assets

## Concept

The symbol maps the product flow into one compact shape:

1. Three horizontal strokes represent raw log lines.
2. The central node branches into a causal evidence graph.
3. The cyan spark represents a resolved, evidence-backed diagnostic insight.

## Core colors

- Midnight: `#172033`
- Signal Violet: `#5B5CF6`
- Insight Cyan: `#06B6D4`
- Ink: `#101828`
- App Background: `#F3F5FF`

## Recommended files

- App/sidebar icon: `logan-app-icon.svg`
- Small transparent symbol: `logan-mark.svg`
- Light UI/README logo: `logan-logo-light.svg`
- Dark navigation/header logo: `logan-logo-dark.svg`
- Logo with descriptor: `logan-lockup-light.svg` or `logan-lockup-dark.svg`
- GitHub social preview: `logan-github-social-preview.png`
- Browser icon: `favicon.ico` or `logan-app-icon-32.png`

The production logo SVGs have outlined wordmarks for consistent rendering. The `*-editable.svg` files retain editable text using Inter.

## Clear space

Keep clear space around the icon equal to at least one node diameter (about 12% of the icon width). Do not place the gradient logo on highly saturated or visually busy backgrounds.

## Existing UI integration

The colors intentionally match the current LogAn theme tokens and sidebar gradient. Use the dark logo in the navy sidebar and the light logo in README pages or light product surfaces.
